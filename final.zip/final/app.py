from flask import Flask, render_template, request
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn import svm
from sklearn.metrics import accuracy_score

# Initialize Flask app
app = Flask(__name__)

# Load and preprocess data
parkinsons_data = pd.read_csv('parkinsons.csv')
X = parkinsons_data.drop(columns=['name', 'status'], axis=1)
Y = parkinsons_data['status']

# Train-test split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=2)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Train the SVM model
model = svm.SVC(kernel='linear')
model.fit(X_train, Y_train)

# Evaluate the model accuracy
X_train_prediction = model.predict(X_train)
training_data_accuracy = accuracy_score(Y_train, X_train_prediction)

X_test_prediction = model.predict(X_test)
test_data_accuracy = accuracy_score(Y_test, X_test_prediction)

# Flask Routes
@app.route('/')
def home():
    return render_template('index.html', training_data_accuracy=training_data_accuracy, test_data_accuracy=test_data_accuracy)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Retrieve form data
        input_data = []
        for i in range(1, 23):
            input_data.append(float(request.form[f"feature{i}"]))

        # Convert the input data to a numpy array and reshape
        input_data = np.array(input_data).reshape(1, -1)

        # Standardize the input data
        standardized_data = scaler.transform(input_data)

        # Make prediction using the trained model
        prediction = model.predict(standardized_data)

        # Generate prediction result
        if prediction[0] == 0:
            result = "The Person does NOT have Parkinson's Disease."
        else:
            result = "The Person has Parkinson's Disease."

    except Exception as e:
        result = f"Error: {str(e)}. Please provide 22 numerical values separated by commas."

    return render_template('index.html', prediction=result, training_data_accuracy=training_data_accuracy, test_data_accuracy=test_data_accuracy)

# Run Flask app
if __name__ == "__main__":
    app.run(debug=True)
